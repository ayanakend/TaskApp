package com.example.taskapp.ui.home

data class TaskModel(
    var title: String? = null,
    var desc: String? = null,
)
